function goBack() {
    document.getElementById('browserFrame').contentWindow.history.back();
}

function goForward() {
    document.getElementById('browserFrame').contentWindow.history.forward();
}

function reload() {
    document.getElementById('browserFrame').contentWindow.location.reload();
}

function goToUrl() {
    var url = document.getElementById('urlInput').value;
    if (!url.startsWith('http://') && !url.startsWith('https://')) {
        url = 'https://' + url;
    }
    document.getElementById('browserFrame').src = url;
}
